import socket
import threading
import tkinter as tk
from tkinter import scrolledtext, simpledialog
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(("localhost", 12345))
class ChatApp:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("Chat Room")

        self.chat_label = tk.Label(self.window, text="Chat:")
        self.chat_label.pack()

        self.text_area = scrolledtext.ScrolledText(self.window)
        self.text_area.pack()
        self.text_area.config(state='disabled')

        self.msg_label = tk.Label(self.window, text="Message:")
        self.msg_label.pack()

        self.input_area = tk.Text(self.window, height=2)
        self.input_area.pack()

        self.send_button = tk.Button(self.window, text="Send", command=self.send_msg)
        self.send_button.pack()

        self.nickname = simpledialog.askstring("Nickname", "Choose your nickname:", parent=self.window)
        threading.Thread(target=self.receive_msgs).start()
        self.window.mainloop()
    def send_msg(self):
        msg = f"{self.nickname}: {self.input_area.get('1.0', 'end')}"
        
        # 👇👇 Show your own message immediately in chat window
        self.text_area.config(state='normal')
        self.text_area.insert('end', msg)
        self.text_area.yview('end')
        self.text_area.config(state='disabled')

        client.send(msg.encode('utf-8'))
        self.input_area.delete('1.0', 'end')

    def receive_msgs(self):
        while True:
            try:
                msg = client.recv(1024).decode('utf-8')
                self.text_area.config(state='normal')
                self.text_area.insert('end', msg)
                self.text_area.yview('end')
                self.text_area.config(state='disabled')
            except:
                break

ChatApp()