import socket
import threading

clients = []

def broadcast(msg, _client):
    for client in clients:
        if client != _client:
            try:
                client.send(msg)
            except:
                client.close()
                clients.remove(client)

def handle_client(client):
    while True:
        try:
            msg = client.recv(1024)
            broadcast(msg, client)
        except:
            clients.remove(client)
            client.close()
            break

def start_server():
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind(("localhost", 12345))
    server.listen()
    print("Server started...")

    while True:
        client, _ = server.accept()
        clients.append(client)
        threading.Thread(target=handle_client, args=(client,)).start()

start_server()